static const char SNAPSHOT[] = "140610";
