#ifndef LUA_CURL_SHARE_H
#define LUA_CURL_SHARE_H

typedef struct l_share_userdata {
  CURLSH *curlsh;
} l_share_userdata;


#endif
