This is a skeleton file for running RingoJS on Google App Engine.
To create a new Google App Engine app based on this skeleton run the
following command:

  ringo-admin create --google-appengine

You need the Google App Engine SDK for Java in order to run and deploy
the application. You can get the SDK and more information from
<http://code.google.com/appengine/>.
