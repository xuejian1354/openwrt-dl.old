An application that creates module API docs from jsdoc style comments.
