var test = require('test');
test.assert(require('a') === exports, 'reflexive import');
