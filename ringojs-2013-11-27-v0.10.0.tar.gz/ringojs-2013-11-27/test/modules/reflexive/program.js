var test = require('test');
require('a');
test.print('DONE', 'info');
