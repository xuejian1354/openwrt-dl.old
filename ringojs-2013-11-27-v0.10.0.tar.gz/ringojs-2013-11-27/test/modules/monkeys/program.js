var b = require('b');
var a = require('a');
var test = require('test');
test.assert(b.monkey == 10, 'monkeys permitted');
test.print('DONE', 'info');
