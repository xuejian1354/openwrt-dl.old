var test = require('test');
var a = require('a');
test.assert(a.b() === exports, 'exact exports');
