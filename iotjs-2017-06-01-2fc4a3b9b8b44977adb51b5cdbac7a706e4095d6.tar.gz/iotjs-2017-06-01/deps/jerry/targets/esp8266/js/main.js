function sysloop(ticknow) {
  blink();
};
print("main js OK");
