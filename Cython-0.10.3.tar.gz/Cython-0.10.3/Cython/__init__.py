# Void cython.* directives (for case insensitive operating systems). 
from Shadow import *
